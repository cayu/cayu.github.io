#!/bin/bash

FILE="$Id: //bas/701_REL/src/ccm/pfoscoll/pflinuxapi.c#1 $"
REVISION="$Revision: #1 $"
REVDATE="$Date: 2007/09/25 $"

# calculate VERSION string
REVISION=`echo $REVISION | sed -e "s/.*#//" | sed -e "s/ .*//"` 
REVDATE=`echo $REVDATE | sed -e "s/.* 20/20/" | sed -e "s/ .*//"`
VERSION="Revision $REVISION ($REVDATE)"

# use US-language to get english messages
export LANG=us


function do_output () 
{
# extend Path
PATH=$PATH:/usr/sbin/:/sbin/

# Check for a SUSE system
SUSE=`cat /etc/*-release | grep -i SUSE`

echo "-------------------------------------------------------------------------------"
echo "START OF SAP SYSTEM INFORMATION TOOL-------------------------------------------"
echo "-------------------------------------------------------------------------------"
echo "-------------------------------------------------------------------------------"
echo "SAP SYSTEM INFORMATION TOOL - $VERSION"
echo "(C) 2005-2006 by SAP LinuxLab - http://www.sap.com/linux"
echo 
echo "Current date: `date`"
echo "User running this script : `whoami`  [ `id` ]"
echo
echo "-------------------------------------------------------------------------------"
echo "System architecture:"
uname -a 2>&1
cat /proc/version 2>&1
 
echo
echo "-------------------------------------------------------------------------------"
echo "Virtualization:"
if [ -f /proc/xen/capabilities ]; then  # XEN ?
  if [ `grep control_d /proc/xen/capabilities | wc -l` -eq 1 ]; then
    echo "-> XEN virtualization active. Running in DOM0 (XEN controlling instance)."
  else
    echo "-> XEN virtualization active. Running in DOMU (it's a XEN virtual machine)."
  fi
else
  # VMWare ?
  #if [ `lsmod | grep ^vm | wc -l` -eq 0 ]; then
    echo "-> Not in a virtualized environment."
  #else
  #  echo "-> Might be virtualized by VMWare or VirtualPC (not sure!)."
  #fi
fi

echo
echo "-------------------------------------------------------------------------------"
echo "Distribution:"
grep '' /etc/*-release /dev/null 2>&1

#if [ "$SUSE" ]; then
#  if [ -e /usr/bin/SPident ]; then
#    SPident 2>&1 			#SUSE: Try to identify the Service Pack level."  
#  fi
#fi

echo
echo "-------------------------------------------------------------------------------"
echo "LSB Release:"
lsb_release 2>/dev/null || echo "'lsb_release' not installed"

echo
echo "-------------------------------------------------------------------------------"
echo -e "Running Linux Kernel: \n (might be truncated on older SLES versions - \n see \"Installed Linux Kernel RPMs\" for more info about the Linux Kernel):"
uname -r 2>&1
 
echo
echo "-------------------------------------------------------------------------------"
echo "Kernel's commandline:"
cat /proc/cmdline 2>&1
 
echo
echo "-------------------------------------------------------------------------------"
echo "System's uptime:"
uptime 2>&1
 
echo
echo "-------------------------------------------------------------------------------"
echo "Installed Linux Kernel RPMs:"
rpm -qa | grep ^k_  2>/dev/null || rpm -qa | grep ^kernel-  2>/dev/null
 
echo
echo "-------------------------------------------------------------------------------"
echo "glibc and saplocales - saplocales must be (re)installed _after_ glibc:" 
# rpm -q --queryformat 'Installtime: %{INSTALLTIME:date}    RPM-Package:  %{NAME}: %{VERSION}-%{RELEASE}\n' glibc saplocales 2>&1
for RPM in glibc saplocales; do
  rpm -q ${RPM} > /dev/null 2>&1;
  # if RPM package is installed
  if [ $? -eq 0 ]; then
    rpm -q --queryformat '%{NAME}-%{VERSION}-%{RELEASE}@%{INSTALLTIME:date}@%{arch}\n' $RPM | awk -F@ '{printf ("RPM-Package: %-20s Installtime: %-30s Architecture: %-8s\n", $1, $2, $3);}'
  else
    rpm -q ${RPM} 2>&1
  fi
done

# On Linux on Power, the IBM XL C/C++ Runtime is required for different DBs. Check here if installed.
ARCH=`uname -m`
if [ "${ARCH:0:5}" == ppc64 ]; then
  echo
  echo "-------------------------------------------------------------------------------"
  echo "Installed IBM(R) XL C/C++ Advanced Edition runtime RPMs:"
  for RPM in vacpp.rte xlsmp.rte xlsmp.msg.rte vac.lib; do
    rpm -q ${RPM} > /dev/null 2>&1;
    # if RPM package is installed
    if [ $? -eq 0 ]; then
      rpm -q --queryformat '%{NAME}-%{VERSION}-%{RELEASE}@%{INSTALLTIME:date}@%{arch}\n' $RPM | awk -F@ '{printf ("RPM-Package: %-20s Installtime: %-30s Architecture: %-8s\n", $1, $2, $3);}'
    else
      rpm -q ${RPM} 2>&1
    fi
  done
fi
ARCH=

if [ "$SUSE" ]; then
  echo 
  echo "-------------------------------------------------------------------------------"
  echo "On SUSE the 'suse-sapinit' or 'sapinit' package should be installed:" 
  { rpm -q sapinit 2>/dev/null || rpm -q suse-sapinit 2>/dev/null ; } | grep -v '^package .* is not installed$'
  if [ $? -ne 0 ]; then
    echo "... not installed"
  fi
fi
 
echo 
echo "-------------------------------------------------------------------------------"
echo "-------------------------------------------------------------------------------"
echo "Linux system information:"
echo 
echo "-------------------------------------------------------------------------------"
echo "Current initial Linux kernel parameter settings (might not be active):" 
cat /etc/sysctl.conf 2>&1
 
echo 
echo "-------------------------------------------------------------------------------"
echo "/proc/sys/kernel/shmmax"		# Maximum size of a SysV Shared Memory segment 
SHMMAX=`cat /proc/sys/kernel/shmmax 2>&1`
echo "$SHMMAX ($(( ${SHMMAX}/1024/1024 )) MB)"

echo 
echo "/proc/sys/kernel/shmall"		# Maximum amount of SysV Shared Memory in 4 KB pages 
SHMALL=`cat /proc/sys/kernel/shmall 2>&1`
echo "$SHMALL ($(( ${SHMALL}*4096/1024/1024 )) MB)"

echo 
echo "/proc/sys/kernel/msgmni"
cat /proc/sys/kernel/msgmni 2>&1
 
echo
echo "/proc/sys/kernel/sem"
cat /proc/sys/kernel/sem 2>&1
 
if [ "$SUSE" ]; then
  if [ -e /proc/sys/vm/heap-stack-gap ]; then
    echo
    echo "/proc/sys/vm/heap-stack-gap"
    cat /proc/sys/vm/heap-stack-gap 2>&1
  fi

  if [ -e /proc/sys/vm/vm_shmem_swap ]; then
    echo
    echo -e "/proc/sys/vm/vm_shmem_swap \n - '1' if new MM for large RAM equipment enabled \n - '0' if not "
    cat /proc/sys/vm/vm_shmem_swap 2>&1
  fi
fi



####################### CPU Detection ###################
echo
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo "CPU information:"
echo
ARCH=`uname -m`
COUNTCPU=`grep -c '^processor' /proc/cpuinfo`
SPEEDCPU=`grep 'cpu MHz' /proc/cpuinfo | sort | uniq`

# Linux on zSeries?
if [ "${ARCH:0:4}" == s390 ]; then
  COUNTCPU=`grep "^processors" /proc/cpuinfo | awk -F " : " '{print $2}'`
  SPEEDCPU=`grep 'bogomips' /proc/cpuinfo | sort | uniq`
fi

# CPU model / vendor
CPUMODEL=`grep "model name" /proc/cpuinfo | uniq`
# Linux on zSeries or Itanium?
if [ -z "$CPUMODEL" ]; then
  CPUMODEL=`grep "vendor" /proc/cpuinfo | uniq`
fi

# Linux on Power?
if [ "${ARCH:0:5}" == ppc64 ]; then
  SPEEDCPU=`grep 'clock' /proc/cpuinfo | uniq | awk -F ": " '{print $2}'`
  CPUMODEL=`grep "machine" /proc/cpuinfo | uniq | awk -F ": " '{print $2}'`
fi

# print first part of cpu information
echo "Found ${COUNTCPU} CPU(s) on this system."
echo
echo -e "CPU frequency: \n ${SPEEDCPU}"
echo
echo -e "CPU model / vendor: \n ${CPUMODEL}"
echo 
echo -e "Kernel architecture :  ${ARCH} \n"

# Hyperthreading - Multicore
#
SOCKETS=`grep '^physical id' /proc/cpuinfo | sort -u | wc -l`
if [ $SOCKETS -eq 0 ]
then
  SOCKETS=`grep '^siblin' /proc/cpuinfo | sort -u | awk -F: '{print $2}'`
  if [ -z "$SOCKETS" ]
  then
    SOCKETS=$COUNTCPU;
  fi
fi

CORES=`grep '^cpu cores' /proc/cpuinfo | awk -F: '{print $2}' | sort -u`
if [ -z "$CORES" ]; then CORES=1; fi

HTAWARE=`egrep '^flags.* ht |^flags.* ht$' /proc/cpuinfo`

  if [ "${HTAWARE}" ]; then
    # RHEL 3, SLES 8 and SLES 9 show 'physical id' in /proc/cpuinfo
    # RHEL 2.1 does not - but shows sibling information in /var/log/dmesg
    # SLES 7 - probably /var/log/boot.msg
    echo "Hyperthreading flag detected!"
    echo
        if [ $SOCKETS -eq $((($COUNTCPU/$CORES) / 2)) ];then
                echo -e "->  Hyperthreading IS activated!\n"
        else
                echo -e "->  Hyperthreading NOT activated!"
        fi

  fi
if [ "${ARCH:0:5}" == ppc64 ]; then
  echo 
  echo "------------------Linux on Power CPU Detailed Information-----------------------"
  cat /proc/ppc64/lparcfg
  echo "--------------------------------------------------------------------------------"
else
  echo -e "-->  This is a ${SOCKETS}-way server with $CORES core(s) per socket.\n"
fi

echo 
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo 
echo "Memory information:"
free 2>/dev/null || cat /proc/meminfo 2>&1
 
echo
echo "--------------------------------------------------------------------------------"
echo "Swap space(s):" 
cat /proc/swaps 2>&1
 

####################### /dev/shm ########################
echo
echo "--------------------------------------------------------------------------------"
echo "TMPFS size"
echo
HEADER="$(df -h -t shm|head -n 1)"
TMPFS="$(df -h -t tmpfs|tail +2)"
# perhaps filesystem type is shm, not tmpfs
if [ ! "$TMPFS" ]; then
  TMPFS="$(df -h -t shm|tail +2)"
fi
TMPFSCOUNT="$(echo "$TMPFS"|wc -l)"

if [ ! "$TMPFS" ]; then
        echo "No filesystem mounted on /dev/shm!"
else
        if [ "$TMPFSCOUNT" -ne 1 ]; then
                echo
                echo "--> Attention - /dev/shm is mounted more than once!"
                echo
        fi
        echo "$HEADER"
        echo "$TMPFS"
fi

echo
echo "--------------------------------------------------------------------------------"
echo "Currently mounted filesystems:"
cat /proc/mounts 2>&1
 
echo
echo "--------------------------------------------------------------------------------"
echo "Filesystems LOCAL disk space usage:"
df -hl 2>&1
 
echo
echo "--------------------------------------------------------------------------------"
echo "Currently loaded modules:"
TAINTED=`cat /proc/sys/kernel/tainted`
if [ $TAINTED == "1" ]; then
  echo
  echo ">> Please note: This Linux Kernel seems to be tainted! <<"
  echo
fi
lsmod 2>/dev/null || cat /proc/modules 2>&1
 

echo 
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo 
echo "Network subsystem:"

echo
HOSTNAME="`hostname`"
echo "hostname        = $HOSTNAME"
echo "hostname --fqdn = `hostname --fqdn`" 


echo 
echo "--------------------------------------------------------------------------------"
echo "local /etc/hosts entries:"
for addr in $(hostname -s; hostname -f; ip addr show | egrep '^ *inet6?' | awk '{print $2}' | cut -d/ -f1); do fgrep "$addr" /etc/hosts; done | sort -u

echo 
echo "--------------------------------------------------------------------------------"
echo "local /etc/nsswitch.conf entries:"
cat /etc/nsswitch.conf | grep -v '^#' | grep '.'

echo 
echo "--------------------------------------------------------------------------------"
echo "current network-card configuration:"
/sbin/ifconfig 2>&1


echo
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo
echo " SAP Instance Profiles"
echo "--------------------------------------------------------------------------------"
echo

PROFILES=$(ls -1 /usr/sap/???/SYS/profile/???_*_$HOSTNAME 2>/dev/null)
# no SAP system installed?
if [ -z "$PROFILES" ]; then
        PROFILES=$(ls -1 /usr/sap/???/SYS/profile/???_*_* 2>/dev/null)
        echo "found the following SAP profile(s):"
else
        echo "found the following SAP profile(s) on this machine ($HOSTNAME):"
fi

# still necessary?
if [ "$PROFILES" = '/usr/sap/???/SYS/profile/???_*_'"*" ]; then
        PROFILES=''
fi

function prof_param() {
  local param="$1"
  local unit="$2"
  local tmp=""

  local value="`/usr/sap/$SID/SYS/exe/run/sappfpar pf=$PROFILE $param 2>/dev/null`"
  if [ "$value" ]; then
    printf '%-30s %s %s' "$param:" "$value" "$unit"
    # calculate amount in MB
    case "$unit" in
      "B")
        tmp="($(( ${value}/1024/1024 )) MB)"
      ;;
      "KB")
        tmp="($(( ${value}/1024 )) MB)"
      ;;
      "8KB blocks")
        tmp="($(( ${value}/128 )) MB)"
      ;;
      *)
        tmp=""
      ;;
    esac
    # print value
    printf ' %s \n' "$tmp"

  else
    printf '%-25s not set!\n' "$param"
  fi

  if [ "$param" = "es/implementation" ]; then
    ES_IMPLEMENTATION=$value
  fi
}

if [ "$PROFILES" ]; then
  for PROFILE in $PROFILES; do
    echo "  $PROFILE"
  done

  for PROFILE in $PROFILES; do
    # profile suddenly disappeared?
    if [ ! -e "$PROFILE" ]; then
      continue
    fi
    echo
    echo
    echo "--------------------------------------------------------------------------------"
    echo
    echo "          $PROFILE"
    echo
    echo "--------------------------------------------------------------------------------"

    echo
    SID="`basename $PROFILE | cut -c 1-3`"
    echo "SystemID:                $SID"
    echo

    export LD_LIBRARY_PATH="/usr/sap/$SID/SYS/exe/run:$LD_LIBRARY_PATH"
    # SAP Kernel release
    SAPKERNEL=`/usr/sap/$SID/SYS/exe/run/disp+work 2>/dev/null | grep "kernel release" | awk -F " " '{ print $3 }'`
    echo "SAP Kernel release:      $SAPKERNEL"
    # SAP Kernel make variant
    SAPKERNELMAKEVAR=`/usr/sap/$SID/SYS/exe/run/disp+work 2>/dev/null | grep "kernel make variant" | awk -F " " '{ print $4 }'`
    echo "SAP Kernel make variant: $SAPKERNELMAKEVAR"
    # SAP Kernel build architecture
    SAPKERNELARCH=`/usr/sap/$SID/SYS/exe/run/disp+work 2>/dev/null | grep "compiled on" | awk -F " " '{ print $6 }'`
    # SAP Kernel compilation mode: Unicode / NonUnicode
    SAPKERNELCOMPMODE=`/usr/sap/$SID/SYS/exe/run/disp+work 2>/dev/null | grep "compilation mode" | awk -F " " '{ print $3 }'`
    # SAP Patch number
    SAPKERNELPATCH=`/usr/sap/$SID/SYS/exe/run/disp+work 2>/dev/null | grep "patch number" | awk -F " " '{ print $3 }'`
    echo "SAP Kernel patch number: $SAPKERNELPATCH"
    echo 

    echo "Memory Poolsizes:"
    /usr/sap/$SID/SYS/exe/run/sappfpar check pf=$PROFILE 2>/dev/null | grep -A 3 " Key:   10"
    echo
    /usr/sap/$SID/SYS/exe/run/sappfpar check pf=$PROFILE 2>/dev/null | grep -A 3 " Key:   40"

    echo
    echo "Overview Shared Memory:"
    /usr/sap/$SID/SYS/exe/run/sappfpar check pf=$PROFILE 2>/dev/null | grep -A 3 "Shared memory....................:"

    echo
    echo "Listing of Linux special memory management parameters:"
    prof_param es/implementation

    if [ "$ES_IMPLEMENTATION" = "map" ]; then
      echo "  --> New SAP Memory Management on Linux activated..."
      PHYSMEMSIZE_PROFILE="`grep ^PHYS_MEMSIZE $PROFILE`"
      if [ "$PHYSMEMSIZE_PROFILE" ]; then
        echo "    PHYS_MEMSIZE(profile): $PHYSMEMSIZE_PROFILE"
      else
        echo "    --> PHYS_MEMSIZE not set in profile - so the system will assume 100% <--"
      fi
    else
      echo "  --> Standard SAP Memory Management" 
    fi

    echo
    prof_param em/initial_size_MB MB
    prof_param em/max_size_MB MB
    prof_param em/blocksize_KB KB
    echo 
    prof_param em/address_space_MB MB
    prof_param em/global_area_MB MB
    if [ "${SAPKERNEL#4}" = "$SAPKERNEL"   ]; then
      if [ "$SAPKERNEL" -ge 640 ]; then    
        prof_param abap/shared_objects_size_MB MB
      fi
    fi
    echo
    prof_param rdisp/ROLL_SHM "8KB blocks"
    prof_param rdisp/ROLL_MAXFS "8KB blocks"
    prof_param rdisp/PG_SHM "8KB blocks"
    prof_param rdisp/PG_MAXFS "8KB blocks"
    echo
    prof_param ztta/roll_area B
    prof_param ztta/roll_first B
    prof_param ztta/roll_extension B
    prof_param ztta/max_memreq_MB MB
    echo
    echo "Heap parameters:"
    prof_param abap/heap_area_total B
    prof_param abap/heap_area_dia B
    prof_param abap/heap_area_nondia B
    echo
    echo "Some Buffer sizes:"
    prof_param abap/buffersize KB
    prof_param zcsa/table_buffer_area B

    # print out the whole profile
    echo
    echo
    echo "Whole content of '$PROFILE':"
    echo
    cat $PROFILE 2>&1

  done

else

  echo " --> No SAP system installed! <--"

fi

echo 
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo "Content of /etc/security/limits.conf"
grep -v '#' /etc/security/limits.conf 2>&1

echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo "JAVA information:"
echo
echo "Java environment variables:"
set | grep JAVA
echo

JA="`which java`"
JF=1
if [ "$JA" = "" ]; then
  JA="none found."
  JF=0
fi
echo "which java   : $JA"
echo

echo
R=`rpm -qa | grep -i java`  # all java RPM packages:
echo "installed JAVA related RPM packages:"
echo $R | tr ' ' '\n'

for i in $R ; do
 echo
 echo "RPM package: $i"
 # Assume only one link to java needed
 JB="`rpm -ql $i | grep bin/java$ | head -1`"
 if [ "$JB" = "" ]; then
   echo "does not contain a java executable"
 else
   rpm -qi $i | head - -n 10
   echo
   echo "Java binary:"
   echo $JB
   echo
   echo "Java fullversion / version:"
    $JB -fullversion 2>&1
    echo
    $JB -version 2>&1
   echo
 fi
done

unset R
unset JA
unset JF
unset JB
unset i

echo 
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo "Current shared memory status:"
ipcs 2>&1

echo 
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo 
echo "Hardware information (lspci):"
lspci -v

echo 
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo 
echo "Hardware information (dmidecode):"
if [ -x /usr/sbin/dmidecode ]; then 
  if [ `id -u` -eq 0 ]; then 
    /usr/sbin/dmidecode 2>&1; 
  else 
    echo "Can't run dmidecode as non root user... Skipping..."; 
  fi; 
else
  echo "Couldn't find dmidecode... Skipping...";
fi

echo 
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo 
echo "Current boot log:"
dmesg 2>&1


echo 
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo " END OF SAP SYSTEM INFORMATION TOOL --------------------------------------------"
echo "--------------------------------------------------------------------------------"
}


do_output 2>&1
