#!/usr/bin/perl -w
#
#
# Description:
# this plugin determines the memory usage of a lotus notes server through SNMP.
#
# This plugin is a derivate of work by Patrick PROY http://www.manubulon.com/nagios .
# Usage:
# check_lotus_mem.pl -H <hostname> -C <community> -w <warnthres> -c <critthres> [-v] [-V] [-t <timeout>]
# Description:
# hostname : lotus domino server to query
# community: snmp community (you need to have the lotus SNMP agent running)
# warnthres (warning threshold) and critthres (critical threshold) are expressed as percents for mem usage
#
# Licence:
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Author: S.bastien Barbereau nagdevel@barbich.net
# Last Changed: $LastChangedDate: 2005-11-04 15:44:14 +0100 (Fri, 04 Nov 2005) $
# Revision:  $Rev: 50 $

#

use strict;
use Net::SNMP;
use Getopt::Long;

# Nagios specific

use lib "/usr/local/nagios/libexec";
use utils qw(%ERRORS $TIMEOUT);
#my $TIMEOUT = 15;
#my %ERRORS=('OK'=>0,'WARNING'=>1,'CRITICAL'=>2,'UNKNOWN'=>3,'DEPENDENT'=>4);

# SNMP Datas

# Net-snmp memory

my $lnMemAllocTotal     = "1.3.6.1.4.1.334.72.1.1.9.1.0";  # lnMemAllocTotal
my $lnMemPhysicalRAM    = "1.3.6.1.4.1.334.72.1.1.9.7.0";
my @mem_oids=($lnMemAllocTotal,$lnMemPhysicalRAM);
# Globals

my $Version='0.9';

my $o_host =    undef;          # hostname
my $o_community = undef;        # community
my $o_port =    161;            # port
my $o_help=     undef;          # wan't some help ?
my $o_verb=     undef;          # verbose mode
my $o_version=  undef;          # print version
my $o_netsnmp=  1;              # Check with netsnmp (default)
my $o_timeout=  5;              # Default 5s Timeout
my $o_version2= undef;          # use snmp v2c
my $o_warning=  50;
my $o_critical= 75;
# SNMPv3 specific
my $o_login=    undef;          # Login for snmpv3
my $o_passwd=   undef;          # Pass for snmpv3

# functions

sub p_version { print "check_snmp_mem version : $Version\n"; }

sub print_usage {
    print "Usage: $0 [-v] -H <host> -C <snmp_community> -w <warning pct> -c <critical pct> [-t <timeout>] [-V]\n";
}

sub help {
   print "\nSNMP Lotus Notes server memory usagefor Nagios version ",$Version,"\n";
   print "(c)2005 - Author: Sebastien BARBEREAU\n\n";
   print_usage();
   print <<EOT;
-v, --verbose
   print extra debugging information (including interface list on the system)
-h, --help
   print this help message
-H, --hostname=HOST
   name or IP address of host to check
-C, --community=COMMUNITY NAME
   community name for the host s SNMP agent (implies SNMP v1 or v2c with option)
-w, --warning
   threshold in percent for warning
-c, --critical
   threshold in percent for critical
-2, --v2c
   Use snmp v2c
-l, --login=LOGIN
   Login for snmpv3 authentication (implies v3 protocol with MD5)
-x, --passwd=PASSWD
   Password for snmpv3 authentication
-P, --port=PORT
   SNMP port (Default 161)
-t, --timeout=INTEGER
   timeout for SNMP in seconds (Default: 5)
-V, --version
   prints version number
EOT
}

sub round ($$) {
    sprintf "%.$_[1]f", $_[0];
}

# For verbose output
sub verb { my $t=shift; print $t,"\n" if defined($o_verb) ; }

# Get the alarm signal (just in case snmp timout screws up)
$SIG{'ALRM'} = sub {
     print ("ERROR: Alarm signal (Nagios time-out)\n");
     exit $ERRORS{"UNKNOWN"};
};

sub check_options {
    Getopt::Long::Configure ("bundling");
    GetOptions(
        'v'     => \$o_verb,            'verbose'       => \$o_verb,
        'h'     => \$o_help,            'help'          => \$o_help,
        'H:s'   => \$o_host,            'hostname:s'    => \$o_host,
        'p:i'   => \$o_port,            'port:i'        => \$o_port,
        'C:s'   => \$o_community,       'community:s'   => \$o_community,
        'l:s'   => \$o_login,           'login:s'       => \$o_login,
        'x:s'   => \$o_passwd,          'passwd:s'      => \$o_passwd,
        't:i'   => \$o_timeout,         'timeout:i'     => \$o_timeout,
        'w:i'   => \$o_warning,         'warning:i'     => \$o_warning,
        'c:i'   => \$o_critical,        'critical:i'     => \$o_critical,
        'V'     => \$o_version,         'version'       => \$o_version,
        '2'     => \$o_version2,        'v2c'           => \$o_version2,
    );
    if (defined ($o_help) ) { help(); exit $ERRORS{"UNKNOWN"}};
    if (defined($o_version)) { p_version(); exit $ERRORS{"UNKNOWN"}};
    if ( ! defined($o_host) ) # check host and filter
        { print "No host defined!\n";print_usage(); exit $ERRORS{"UNKNOWN"}}
    # check snmp information
    if ( !defined($o_community) && (!defined($o_login) || !defined($o_passwd)) )
        { print "Put snmp login info!\n"; print_usage(); exit $ERRORS{"UNKNOWN"}}

}

########## MAIN #######

check_options();

# Check gobal timeout if snmp screws up
if (defined($TIMEOUT)) {
  verb("Alarm at $TIMEOUT");
  alarm($TIMEOUT);
} else {
  verb("no timeout defined : $o_timeout + 10");
  alarm ($o_timeout+10);
}

# Connect to host
my ($session,$error);
if ( defined($o_login) && defined($o_passwd)) {
  # SNMPv3 login
  verb("SNMPv3 login");
  ($session, $error) = Net::SNMP->session(
      -hostname         => $o_host,
      -version          => '3',
      -username         => $o_login,
      -authpassword     => $o_passwd,
      -authprotocol     => 'md5',
      -privpassword     => $o_passwd,
      -timeout          => $o_timeout
   );
} else {
   if (defined ($o_version2)) {
     # SNMPv2 Login
         ($session, $error) = Net::SNMP->session(
        -hostname  => $o_host,
            -version   => 2,
        -community => $o_community,
        -port      => $o_port,
        -timeout   => $o_timeout
     );
   } else {

    # SNMPV1 login
    ($session, $error) = Net::SNMP->session(
       -hostname  => $o_host,
       -community => $o_community,
       -port      => $o_port,
       -timeout   => $o_timeout
    );
  }
}
if (!defined($session)) {
   printf("ERROR opening session: %s.\n", $error);
   exit $ERRORS{"UNKNOWN"};
}

# Global variable
my $resultat=undef;

$resultat = (Net::SNMP->VERSION < 4) ?
                 $session->get_request(@mem_oids)
                 :$session->get_request(-varbindlist => \@mem_oids);

if (!defined($resultat)) {
    printf("ERROR: SNMP error : %s.\n", $session->error);
    $session->close;
    exit $ERRORS{"UNKNOWN"};
}

my $memused=undef;
$memused= ($$resultat{$lnMemPhysicalRAM} == 0) ? 0 :
        ($$resultat{$lnMemAllocTotal}/$$resultat{$lnMemPhysicalRAM});
$memused=round($memused*100,0);

my $status="OK";
if($memused>$o_warning) {
    $status="WARNING";
}
if($memused>$o_critical) {
    $status="CRITICAL";
}
if($memused>100) {
    $status="UNKNOWN";
}
my $output=$status.": Memory used:".$memused."%";
$session->close;
print "$output \n";
exit $ERRORS{$status};;
