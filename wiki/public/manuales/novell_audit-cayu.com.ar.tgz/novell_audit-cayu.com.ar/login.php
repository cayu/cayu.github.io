<head>
<link rel="stylesheet" type="text/css" media="all" href="jscalendar/calendar-win2k-cold-2.css" title="win2k-cold-2" />
<script type="text/javascript" src="jscalendar/calendar.js"></script>
<script type="text/javascript" src="jscalendar/lang/calendar-es.js"></script>
<script type="text/javascript" src="jscalendar/calendar-setup.js"></script>
<script language="JavaScript" type="text/javascript" src="login.js"></script></head>
<style>
th {
margin: 2px;
text-align: center;
border-top: 1px #E2DECD outset;
border-left: 1px #E2DECD outset;
border-right: 1px #E2DECD outset;
height: 20px;
font-weight: bold;
background-image: url(border_big.gif);
background-repeat: repeat-x;
}

td {
font-size: 12px;
}

form {
    width:80%;
    margin:auto;
}
form input[type=text] {
    border:1px solid #CCCCCC;
}
form input {
    padding:3px;
    color:#FFFFFF;
    background-color:#A5A5A5;
    border:1px solid #000000;
}
form select {
    padding:3px;
    color:#FFFFFF;
    background-color:#A5A5A5;
    border:1px solid #000000;
}

</style>
</head>
<body bgoclor="background-color: #C3C7D3;">
<div align="center">
<form action="#" method="get" name="reporte" style="font-size:10px;">
<input type="button" id="trigger_desde" value="Desde">
<input type="text" name="date" id="desde" />
<input type="button" id="trigger_hasta" value="Hasta">
<input type="text" name="date" id="hasta" />
Ordenar por : 
<SELECT NAME="order">
   <OPTION VALUE="tiempo">Tiempo</OPTION>
   <OPTION VALUE="usuario">Usuario</OPTION>
   <OPTION VALUE="evento">Evento</OPTION>
</SELECT> 
Filtrar por :
<SELECT NAME="event">
   <OPTION VALUE="">*</OPTION>
   <OPTION VALUE="1">Intruder</OPTION>
   <OPTION VALUE="2">Login</OPTION>
   <OPTION VALUE="3">Login Failed</OPTION>
</SELECT> 
<input type="button" OnClick="enviarDatos();" value="Obtener datos">
</form>
<script type="text/javascript">
    function catcalc(cal) {
        var date = cal.date;
        var time = date.getTime()

        // use the _other_ field
//        var field = document.getElementById("hasta");
//        if (field == cal.params.inputField) {
//            field = document.getElementById("desde");
//            time -= Date.WEEK; // substract one week
//        } else {
//            time += Date.WEEK; // add one week
//        }
//        var date2 = new Date(time);
//        field.value = date2.print("%Y-%m-%d %H:%M:%S");
    }
    Calendar.setup({
        inputField     :    "desde",   // id of the input field
        ifFormat       :    "%Y-%m-%d %H:%M:%S",       // format of the input field
        showsTime      :    true,
        timeFormat     :    "24",
        button         :    "trigger_desde",
        onUpdate       :    catcalc
    });
    Calendar.setup({
        inputField     :    "hasta",
        ifFormat       :    "%Y-%m-%d %H:%M:%S",
        showsTime      :    true,
        timeFormat     :    "24",
        button         :    "trigger_hasta",
        onUpdate       :    catcalc
    });
</script>
<div id="resultado" style="width:90%;text-align:center;" align="center"></div>
</div>
