<html>
<head>
<?php
// NOTA:
//  exec() no funciona con safe_mode:
//    - STDERR es procesado por escapeshellcmd()
//    - no funciona ejecutar binarios externos
// slapd.conf permitir la escritura de uno mismo:
// 	access to *
//                by self write
                
error_reporting(E_ALL);
$textTitle               = 'Cambiar contrase&ntilde;a en '.$_SERVER['SERVER_NAME'];
$textHeader              = 'Cambiar contrase&ntilde;a en '.$_SERVER['SERVER_NAME'];
$msgEnterLogin           = 'Usuario';
$msgEnterCurrentPassword = 'Contrase&ntilde;a actual';
$msgEnterNewPassword     = 'Nueva contrase&ntilde;a';
$msgRepeatNewPassword    = 'Repita la nueva contrase&ntilde;a';
$msgNewPasswordMismatch  = 'Las contrase&ntilde;as no concuerdan. Por favor intente nuevamente.';
$msgNewPasswordUnchanged = 'La nueva contrase&ntilde;a y la anterior son iguales!';
$msgPasswordChanged      = 'Contrase&ntilde;a cambiada!';
$imgOk			 = '<img align=absmiddle src=estilo/ok.png>';
$msgOk                   = 'Cambio exitoso!';
$imgError		 = '<img align=absmiddle src=estilo/error.png>';
$msgError                = 'Error';
////////  HTTP request data  ///////////////////

function get_arg($data, $key) {
	if (array_key_exists($key, $data))
		return html_entity_decode($data[$key]);
	return "";
}

    $userLogin = get_arg($_REQUEST, 'login');
    $currentPassword = get_arg($_POST, 'currentPassword');
    $newPassword = get_arg($_POST, 'newPassword');
    $repeatNewPassword = get_arg($_POST, 'repeatNewPassword');

$ldapPasswd    = '/usr/local/openldap/bin/ldappasswd -h 10.251.1.215 ';
// BindDN, based on predefined $userLogin value
$ldapFullUsername = "uid=$userLogin,ou=users,dc=pan-energy";
?>
<title><?php echo $textTitle;?></title>
<LINK media=screen href="estilo/theme.css" type=text/css rel=stylesheet>
</head>
<body><br>
<center><h2><?php echo $textHeader;?></h2></center>
<?php
function put_box($title, $titleForeColor, $titleBackColor, $msg, $msgForeColor, $msgBackColor) {
    if (is_array($msg))
	$msg = implode('<br/>', $msg);
echo "<table border='0' cellpadding='10' align='center' bgcolor='$titleBackColor'>
<tr><th align='left' valign='center' bgcolor='$titleBackColor'><font color='$titleForeColor'><big>$title</big></font></th></tr>
<tr><td align='left' valign='center' bgcolor='$msgBackColor'  ><font color='$msgForeColor'  >$msg</font></td></tr>
</table>
";
}

function    ok_box($text) { global $msgOk,$imgOk;    	put_box($imgOk.$msgOk,    'White',  'Blue', $text, 'Green', 'Wheat'); }
function error_box($text) { global $msgError,$imgError; put_box($imgError.$msgError, 'Yellow', 'Red',  $text, 'Red',   'Wheat'); }

$runForm = TRUE;

if ($userLogin && $currentPassword && $newPassword && $repeatNewPassword) {
	if ($newPassword != $repeatNewPassword) {
		error_box($msgNewPasswordMismatch);
	} elseif ($newPassword == $currentPassword) {
		error_box($msgNewPasswordUnchanged);
	} else {
		$ldapOutput = array();
		$ldapCommand = "$ldapPasswd -v -x -D '$ldapFullUsername'"
			.(isset($ldapURI) ? " -h '$ldapURI'" : "")
			." -s '$newPassword' -w '$currentPassword'";
		exec(escapeshellcmd($ldapCommand).' 2>&1', $ldapOutput, $ldapResult);
		echo "<!-- Debug: ldapCommand = '$ldapCommand' -->\n";
		echo "<!-- Debug: ldapOutput  = [ ".implode(' :: ', $ldapOutput)." ] -->\n";
		echo "<!-- Debug: ldapResult  = '$ldapResult' -->\n";
		if ($ldapResult == 0) {
			ok_box($msgPasswordChanged);
			$runForm = FALSE;
		} else {
			error_box($ldapOutput);
		}
	}
}

if ($runForm) {

function put_line($title, $type, $name, $value) {
echo "<tr>
	<td align='left'><img src='estilo/flecha.gif'>$title:</td>
	<td align='left'><input type='$type' name='$name' value='$value' maxlength='255' size=40/></td>
</tr>";
}
?>
<form action='' method=POST>
<p>
<table align="center" cellpadding="3" border="0">
<tr>
<td colspan='2'>
<!-- Mensaje -->
          <TABLE cellSpacing=0 cellPadding=3 border=0>
            <TBODY>
                <TR>
                    <TD>
                	<TABLE cellSpacing=0 cellPadding=3 border=0>
                	    <TR>
                		<TD>
                		<img src="estilo/usuario.gif">
                		</TD>
                		<TD>
                		Recuerde que su contrase&ntilde;a es la llave de acceso a informaci&oacute;n
                		sensible de la empresa.<BR>POR FAVOR, NO LA DIVULGUE!<BR><BR>
                		La contrase&ntilde;a debe tener las siguientes propiedades:
                		</TD>
                	    </TR>
                	</TABLE>
                    </TD>
                </TR>
                <TR>
                    <TD>&nbsp;</TD>
                </TR>
                <TR>
                    <TD>
                        <UL>
                    	    <LI>N&uacute;mero mínimo de caracteres en la contrase&ntilde;a: 8</LI>
                            <LI>N&uacute;mero máximo de caracteres en la contrase&ntilde;a: 24</LI>
                        </UL>
                    </TD>
                </TR>
                <TR>
                    <TD>Puede utilizar n&uacute;meros en la contrase&ntilde;a.</TD>
                </TR>
                <TR>
                    <TD>&nbsp;</TD>
                </TR>
                <TR>
                    <TD>
                        <UL>
                            <LI>N&uacute;mero mínimo de caracteres numéricos en la contrase&ntilde;a: 2</LI>
                        </UL>
                    </TD>
                </TR>
                <TR>
                    <TD>La contrase&ntilde;a distingue entre MAY&Uacute;SCULAS y min&uacute;sculas.</TD>
                </TR>
                <TR>
                    <TD>&nbsp;</TD>
                </TR>
                <TR>
                    <TD>
                        <UL>
                            <LI>N&uacute;mero mínimo de caracteres en may&uacute;scula en la contrase&ntilde;a: 2</LI>
                        </UL>
                    </TD>
                </TR>
                <TR>
                    <TD>Debe utilizar una contrase&ntilde;a exclusiva.</TD>
                </TR>
    </TBODY>
</TABLE>
<!-- Mensaje -->
</td>
</tr>
<?php
    put_line($msgEnterLogin,           'text',     'login',             $userLogin);
    put_line($msgEnterCurrentPassword, 'password', 'currentPassword',   $currentPassword);
    put_line($msgEnterNewPassword,     'password', 'newPassword',       $newPassword);
    put_line($msgRepeatNewPassword,    'password', 'repeatNewPassword', $repeatNewPassword);
?>
    <tr>
	<td colspan='2' align='center' valign='bottom'>
	    <br/>
	    <input type='submit' value='Confirmar' style='border:1px solid #c2e1ef;background-color:#CECECE'/>&nbsp;&nbsp;&nbsp;&nbsp;
	    <input type='reset' style='border:1px solid #c2e1ef;background-color:#CECECE'/>
	</td>
    </tr>
</table>
</p>
</form>
<?php } ?>
</body>
</html>
