function nuevoAjax(){
var xmlhttp=false;
 try {
  xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
 } catch (e) {
  try {
   xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  } catch (E) {
   xmlhttp = false;
  }
 }

if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
  xmlhttp = new XMLHttpRequest();
}
return xmlhttp;
}

function enviarDatos(){
	c = document.getElementById('resultado');
	
	desde=document.reporte.desde.value;
	hasta=document.reporte.hasta.value;
	
	ajax=nuevoAjax();
	c.innerHTML = '<p style="text-align:center;"><img src="esperando.gif"/></p>'; 
	ajax.open("POST", "user_modification_report.php",true);
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4) {
			c.innerHTML = ajax.responseText
		}
	}
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax.send("desde="+desde+"&hasta="+hasta)
}
