<?php
$conexion = pg_connect("host= port=5432 dbname=SIEM user=admin password=admin");
$consulta2="
SELECT DISTINCT
 EVENTS_RPT_V3.EVENT_PARSE_TIME AS EVENT_PARSE_TIME,
 EVENTS_RPT_V3.Event_Name AS EVENT_NAME, 
 EVENTS_RPT_V3.Init_User_Name AS INIT_USER_NAME,
 EVENTS_RPT_V3.Target_User_Name AS TARGET_USER_NAME,
 EVENTS_RPT_V3.TARGET_USER_DOMAIN AS TARGET_USER_DOMAIN,
        EVENTS_RPT_V3.File_Name AS FILE_NAME,
        EVENTS_RPT_V3.Extended_Info AS EXTENDED_INFO,
 (EVT_TXNMY_RPT_V.TAXONONY_LEVEL_2  || ' ' || EVT_TXNMY_RPT_V.TAXONONY_LEVEL_3) AS TAXONOMY_GROUP, 
 EVT_AGENT_RPT_V.AGENT AS AGENT
FROM 
 EVT_AGENT_RPT_V, 
 EVT_TXNMY_RPT_V, 
 EVENTS_RPT_V3 
WHERE 
 EVENTS_RPT_V3.AGENT_ID = EVT_AGENT_RPT_V.AGENT_ID AND
 EVENTS_RPT_V3.TAXONOMY_ID = EVT_TXNMY_RPT_V.TAXONOMY_ID AND
 EVT_TXNMY_RPT_V.TAXONONY_LEVEL_2 = 'USER' AND 
 (EVT_TXNMY_RPT_V.TAXONONY_LEVEL_3 = 'MODIFY' OR 
 EVT_TXNMY_RPT_V.TAXONONY_LEVEL_3 = 'MODIFY FAILURE' OR
 EVT_TXNMY_RPT_V.TAXONONY_LEVEL_3 = 'DELETE') AND
 (EVENTS_RPT_V3.EVENT_PARSE_TIME>=TO_TIMESTAMP('".$_POST['desde']."','YYYY-MM-dd HH24:MI:SS') AND
 EVENTS_RPT_V3.EVENT_PARSE_TIME<=TO_TIMESTAMP('".$_POST['hasta']."','YYYY-MM-dd HH24:MI:SS'))
";
	$ejecutar2=pg_exec($conexion, $consulta2);
	$registro2=pg_num_rows($ejecutar2);
	
	if ($registro2==0) 
	    echo "No hay registros";
	else
		{

echo "<table border=0 cellpadding=0 cellspacing=1>\n";
echo "<tr>\n";
echo "
<th>event_parse_time</th>
<th>event_name</th>
<th>init_user_name</th>
<th>target_user_name</th>
<th>target_user_domain</th>
<th>file_name</th>
<th>extended_info</th>
<th>taxonomy_group</th>
";
echo "</tr>\n";
$row=0;

do
    {
	    $myrow=pg_fetch_assoc($ejecutar2,$row);
	    $row++;
	    if($row %2 == 0) {
		$style = "background-color: #E7E5DD;";
	    } else {
		$style = "background-color: #DEDBD2;";
	    }
echo "<tr style='".$style."'>\n";
echo "<td>".$myrow['event_parse_time']."</td>\n";
echo "<td>".$myrow['event_name']."</td>\n";
echo "<td>".$myrow['init_user_name']."</td>\n";
echo "<td>".$myrow['target_user_name']."</td>\n";
echo "<td>".$myrow['target_user_domain']."</td>\n";
echo "<td>".$myrow['file_name']."</td>\n";
echo "<td>".$myrow['extended_info']."</td>\n";
echo "<td>".$myrow['taxonomy_group']."</td>\n";
echo "</tr>\n";
}//finDo
	while($row < $registro2);
echo "</table>\n";
}//fin else
if ($registro2<>0)
?>
