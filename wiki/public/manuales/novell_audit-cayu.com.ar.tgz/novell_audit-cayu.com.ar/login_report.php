<?php
$conexion = pg_connect("host= port=5432 dbname=SIEM user=admin password=admin");
$ORDER_BY = "ORDER BY ";
switch ($_POST['order']) {
    case "usuario":
	$ORDER_BY.="INIT_USER_NAME";
	break;
    case "evento":
	$ORDER_BY.="EVENT_NAME";
	break;
    case "tiempo":
	$ORDER_BY.="EVENT_PARSE_TIME DESC";
	break;
    default:
	$ORDER_BY.="EVENT_NAME";
}

switch ($_POST['event']) {
    case "1":
	$EVENT="AND EVENT_NAME = 'Intruder Detected'";
	break;
    case "2":
	$EVENT="AND EVENT_NAME = 'Login'";
	break;
    case "3":
	$EVENT="AND EVENT_NAME = 'Login Failed'";
	break;
    default:
	$EVENT="";
}

$consulta2="
	SELECT DISTINCT
 EVENTS_RPT_V3.EVENT_PARSE_TIME AS EVENT_PARSE_TIME,
 EVENTS_RPT_V3.Event_Name AS EVENT_NAME,
 EVENTS_RPT_V3.Init_User_Name AS INIT_USER_NAME,
 EVENTS_RPT_V3.Target_User_Name AS TARGET_USER_NAME,
 EVENTS_RPT_V3.TARGET_USER_DOMAIN AS TARGET_USER_DOMAIN,
 EVENTS_RPT_V3.TARGET_HOST_NAME AS TARGET_HOST_NAME,
 EVENTS_RPT_V3.TARGET_IP_DOTTED AS TARGET_IP,
 EVENTS_RPT_V3.INIT_IP_DOTTED AS SOURCE_IP,
 EVENTS_RPT_V3.Extended_Info AS EXTENDED_INFO,
 (EVT_TXNMY_RPT_V.TAXONONY_LEVEL_2  || ' ' || EVT_TXNMY_RPT_V.TAXONONY_LEVEL_3) AS TAXONOMY_GROUP,
 EVT_AGENT_RPT_V.AGENT AS AGENT
FROM
 EVT_AGENT_RPT_V,
 EVT_TXNMY_RPT_V,
 EVENTS_RPT_V3
WHERE
 EVENTS_RPT_V3.AGENT_ID = EVT_AGENT_RPT_V.AGENT_ID AND
 EVENTS_RPT_V3.TAXONOMY_ID = EVT_TXNMY_RPT_V.TAXONOMY_ID AND
 EVT_TXNMY_RPT_V.TAXONONY_LEVEL_2 = 'USER' AND
 (EVT_TXNMY_RPT_V.TAXONONY_LEVEL_3 = 'LOGIN' OR
 EVT_TXNMY_RPT_V.TAXONONY_LEVEL_3 = 'LOGIN FAILURE') AND
 (EVENTS_RPT_V3.EVENT_PARSE_TIME>=TO_TIMESTAMP('".$_POST['desde']."','YYYY-MM-dd HH24:MI:SS') AND
 EVENTS_RPT_V3.EVENT_PARSE_TIME<=TO_TIMESTAMP('".$_POST['hasta']."','YYYY-MM-dd HH24:MI:SS'))
 ".$EVENT."
 ".$ORDER_BY."
 ";
	$ejecutar2=pg_exec($conexion, $consulta2);
	$registro2=pg_num_rows($ejecutar2);
	
	if ($registro2==0) 
//		echo '<script>alert("No hay registros");window.history.back();</script>';
		echo "No hay registros";
	else
		{
echo "<table border=0 cellpadding=0 cellspacing=1>\n";
echo "<tr>\n";
echo "
<th>event_parse_time</th>
<th>evt</th>
<th>usr</th>
<th>source_ip</th>
<th>target_host</th>
<th>extended_info</th>
<th>taxonomy_group</th>";
echo "</tr>\n";

$row=0;

do
    {
	    $myrow=pg_fetch_assoc($ejecutar2,$row);
	    $row++;
	    if($row %2 == 0) {
		$style = "background-color: #E7E5DD;";
	    } else {
		$style = "background-color: #DEDBD2;";
	    }

echo "<tr style='".$style."'>\n";
echo "<td>".$myrow['event_parse_time']."</td>\n";
if($myrow['event_name'] == "Intruder Detected") {
    $style_auth = "background-color: #FFFFEB;";
}
if($myrow['event_name'] == "Login") {
    $style_auth = "background-color: #C0FFC0;";
}
if($myrow['event_name'] == "Login Failed") {
    $style_auth = "background-color: #FFC0C0;";
}
echo "<td style='".$style_auth."text-align:center;'>&nbsp;".$myrow['event_name']."&nbsp;</td>\n";

if(strlen($myrow['init_user_name'])>0) {
    echo "<td>".$myrow['init_user_name']."</td>\n";
} else {
    echo "<td>".$myrow['target_user_name']."</td>\n";
}
echo "<td>".$myrow['source_ip']."</td>\n";
echo "<td>";
if(strlen($myrow['target_host_name'])>0) {
    echo $myrow['target_host_name'];
} else {
    echo $myrow['target_ip'];
}
echo "</td>\n";
echo "<td>".$myrow['extended_info']."</td>\n";
echo "<td>".$myrow['taxonomy_group']."</td>\n";
echo "</tr>\n";
}//finDo
	while($row < $registro2);
echo "</table>\n";
}//fin else
if ($registro2<>0)
?>