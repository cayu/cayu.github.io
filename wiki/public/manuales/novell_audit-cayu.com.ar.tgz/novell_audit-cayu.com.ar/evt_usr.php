<html>
<head>
<style>
th {
margin: 2px;
text-align: center;
border-top: 1px #E2DECD outset;
border-left: 1px #E2DECD outset;
border-right: 1px #E2DECD outset;
height: 20px;
font-weight: bold;
background-image: url(border_big.gif);
background-repeat: repeat-x;
}

td {
font-size: 12px;
}

form {
    width:60%;
    margin:auto;
}
form input[type=text] {
    border:1px solid #CCCCCC;
}
form input {
    padding:3px;
    color:#FFFFFF;
    background-color:#A5A5A5;
    border:1px solid #000000;
}
form select {
    padding:3px;
    color:#FFFFFF;
    background-color:#A5A5A5;
    border:1px solid #000000;
}

</style>
</head>
<body bgoclor="background-color: #C3C7D3;">
<?php
$conexion = pg_connect("host= port=5432 dbname=SIEM user=admin password=admin");
$consulta2="select * from evt_usr";
	$ejecutar2=pg_exec($conexion, $consulta2);
	$registro2=pg_num_rows($ejecutar2);
	
	if ($registro2==0) 
	    echo "No hay registros";
	else
		{

echo "<table border=0 cellpadding=0 cellspacing=1>\n";
echo "<tr>\n";
echo "
<th>usr_id</th>
<th>usr_name</th>
<th>authority</th>
";
echo "</tr>\n";
$row=0;

do
    {
	    $myrow=pg_fetch_assoc($ejecutar2,$row);
	    $row++;
	    if($row %2 == 0) {
		$style = "background-color: #E7E5DD;";
	    } else {
		$style = "background-color: #DEDBD2;";
	    }
echo "<tr style='".$style."'>\n";
echo "<td>".$myrow['usr_id']."</td>\n";
echo "<td>".$myrow['usr_name']."</td>\n";
echo "<td>".$myrow['authority']."</td>\n";
echo "</tr>\n";
}//finDo
	while($row < $registro2);
echo "</table>\n";
}//fin else
if ($registro2<>0)
?>
</body>
</html>
