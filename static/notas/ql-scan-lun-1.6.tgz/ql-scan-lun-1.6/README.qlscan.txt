             QLogic FC HBA LUN Scan Utility
======================================================================

This utility scans for the newly added LUNs. After adding the new LUNs
it is not required to unload/load the QLogic FC driver or reboot the
system. To see the newly added LUNs, just run the ql-scan-lun.sh utility.

The simplest way to use this utility is to run
	# ./ql-scan-lun.sh

By default the utility would re-scan the QLogic HBAs for new LUNs.

Contents:
=========

1. Supported Features List

2. Driver Supported

3. Utility Command Line Options

4. Utility Menu Options 

5. Usage

6. Known Issues

7. Important Notes


1. Supported Features List
==========================

ql-scan-lun utility provides following features:

	- Re-scan all the QLogic HBAs for new LUNs
	
	- Re-scan and remove lost LUNs from the system

	- By default scan up to 256 LUNs, provides provision to set max LUNs to
	  be scanned

	- By default scans all QLogic HBAs, provides provision to select HBA
	  to be scanned

	- Displays information of each HBAs

2. Driver Support
===================

	Supported QLogic Driver Version:
	-------------------------------
		Fibre Channel :  7.xx.xx, 8.xx.xx

3. Utility Command Line Options
===============================

 -s,  --scan [-r|--refresh]
                        The QLogic LUN scan utility re-scans all the
                        devices connected to the QLogic HBA

                        To refresh, that is remove LUNs that are lost
                        use the options "-r|--refresh". This will
                        remove the LUNs which no more exist.

			NOTE: "refresh" option should be used carefully, since
			doing a refresh would remove the exisiting LUNs first 
			and then does a re-scan.
  -i,  --interactive
                        Use this option to use the menu driven program

  -p, --proc
                        Use PROC file system to do LUN scanning on 2.6 kernel
			on 2.4 kernel the LUN scanning is done based on proc
			file system only.	

  -h,  --help, ?
                        Prints the help message



4. Utility Menu Options 
========================
The menu driver interface can be used to have finer control on the operation
to be performed.

The menu is invoked using the "-i" or "--interactive"  option to the
ql-scan-lun utility
	# ./ql-scan-lun.sh -i

Following menus are provided
4.1. MAIN MENU
--------------
        1: ALL HOSTS SCAN
        2: ALL HOST SCAN & REFRESH
        3: SELECT HOST TO SCAN
        4: SET MAX LUN's TO SCAN (Current: 256)
        5: QUIT

        1: ALL HOSTS SCAN
	=================
	Scans all the QLogic HBAs connected in the system. A message is
	displayed indicating new LUN found.

        2: ALL HOST SCAN & REFRESH
	==========================
	Scans all the QLogic HBAs connected in the system. In addition to a
	re-scan, LUNs that do not exist anymore are removed from the system. 
	For example, if LUN 1 is seen on Host:2, Bus:0 and Device:0 then there
	would be a corresponding entry in /proc/scsi/scsi. Something like this
	
	Host: scsi2 Channel: 00 Id: 00 Lun: 01

	Now if the LUN is removed, the system would still show the LUN being
	present in /proc/scsi/scsi. To remove this LUNS, which is lost, use
	this option to re-scan the HBA.


        3: SELECT HOST TO SCAN
	======================
	Invokes the menu to select a specific QLogic HBA to be scanned. This
	is described in section 4.2

        4: SET MAX LUN's TO SCAN (Current: 256)
	======================================
	By default maximum 256 LUNs are scanned. To change the max LUNs to be
	scanned use this option.

        5: QUIT
	=======
	Exit from the ql-scan-lun utility

4.2: SELECT HOST TO SCAN
------------------------
        1. HOST: scsi2
        2. HOST: scsi3
        3. SET SCAN TYPE (Current : SCAN ONLY)
        4. GO BACK TO PREVIOUS SCREEN
        5. QUIT


	1. HOST: scsi<n>
	================
	Indicates the HBA to be scanned. Selecting this would start the
	re-scan of HBA corresponding to this host number.

        2. SET SCAN TYPE 
	================
	Scan type indicates if just a re-scan has to be done or with re-scan
	LUNs that do not exist anymore are to be removed.
	By default, the utility does a re-scan. This can be changed to 
	"HOST SCAN & REFRESH"

        3. GO BACK TO PREVIOUS SCREEN
	=============================
	Go back to main menu.
	
        4. QUIT
	=======
	Exit from the ql-scan-lun utility


5. Usage
=========
	5.1 To do a re-scan of all the HBAs
		# ./ql-scan-lun.sh 
		# ./ql-scan-lun.sh -s 
		# ./ql-scan-lun.sh --scan
		
	5.2 To do a re-scan  and remove any lost LUNs
		# ./ql-scan-lun.sh -s -r 
		# ./ql-scan-lun.sh --scan --refresh

	5.3 To invoke the menu
		# ./ql-scan-lun.sh -i
		# ./ql-scan-lun.sh --interactive

	5.3 To view help
		# ./ql-scan-lun.sh -h
		# ./ql-scan-lun.sh --help

6. Known Issues
===============
	None

7. Important Notes
==================
	7.1  The "refresh" option during scan should be used carefully, since
	     doing a refresh would remove the exisiting LUNs first and then 
	     does a re-scan.
